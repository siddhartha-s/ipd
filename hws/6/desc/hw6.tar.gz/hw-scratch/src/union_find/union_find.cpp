#include "union_find.hpp"

namespace union_find
{

  int_sets::int_sets()
  {
    // IMPLEMENT THIS
  }

  int_sets::int_sets(size_t size)
  { 
    // IMPLEMENT THIS
  }

  int int_sets::find(int elem) 
  {
    // IMPLEMENT THIS
    return 0;
  }

  void int_sets::do_union(int left, int right)
  {
    // IMPLEMENT THIS
  }

}
