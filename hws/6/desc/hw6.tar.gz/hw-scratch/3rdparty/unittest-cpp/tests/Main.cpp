#include "UnitTest++/UnitTestPP.h"

int main(int, char const *[])
{
    return UnitTest::RunAllTests();
}
