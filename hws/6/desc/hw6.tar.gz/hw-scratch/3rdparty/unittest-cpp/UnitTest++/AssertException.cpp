#include "AssertException.h"

#ifndef UNITTEST_NO_EXCEPTIONS

namespace UnitTest {

AssertException::AssertException()
{
}

AssertException::~AssertException() throw()
{
}

}

#endif
